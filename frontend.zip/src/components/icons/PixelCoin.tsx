import React from 'react';

const PixelCoin = ({ size = 24, className = "" }) => (
  <svg 
    width={size} 
    height={size} 
    className={className} 
    xmlns="http://www.w3.org/2000/svg" 
    fill="currentColor" 
    viewBox="0 0 24 24"
  >
    <path d="M18 22h-6v-2h6v2Zm-6-2h-2v-2h2v2Zm8 0h-2v-2h2v2Zm-8-4h-2v2H8v-2H6v-2h6v2Zm5 2h-2v-4h-3v-2h2V6h2v2h2v2h-2v2h1v6Zm5 0h-2v-6h2v6ZM6 14H4v-2h2v2Zm-2-2H2V6h2v6Zm7 0H9V8H7V6h4v6Zm9 0h-2v-2h2v2ZM6 6H4V4h2v2Zm8 0h-2V4h2v2Zm-2-2H6V2h6v2Z"/>
  </svg>
);

export default PixelCoin;
