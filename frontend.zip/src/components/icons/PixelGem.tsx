import React from 'react';

const PixelGem = ({ size = 24, className = "" }) => (
  <svg 
    width={size} 
    height={size} 
    className={className} 
    xmlns="http://www.w3.org/2000/svg" 
    fill="currentColor" 
    viewBox="0 0 24 24"
  >
    <path d="M13 23h-2v-2h2v2Zm-2-2H9v-2h2v2Zm4 0h-2v-2h2v2Zm-6-2H7v-2h2v2Zm4 0h-2v-3h2v3Zm4 0h-2v-2h2v2ZM7 17H5v-2h2v2Zm12 0h-2v-2h2v2Zm-8-1H9v-3h2v3Zm4 0h-2v-3h2v3ZM5 15H3v-2h2v2Zm16 0h-2v-2h2v2ZM9 9h6V6h2v3h4V7h2v6h-2v-2h-4v2h-2v-2H9v2H7v-2H3v2H1V7h2v2h4V6h2v3ZM5 7H3V5h2v2Zm16 0h-2V5h2v2Zm-6-1h-2V3h-2v3H9V3H7V1h10v2h-2v3ZM7 5H5V3h2v2Zm12 0h-2V3h2v2Z"/>
  </svg>
);

export default PixelGem;
