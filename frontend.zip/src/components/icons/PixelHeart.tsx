import React from 'react';

interface PixelHeartProps {
  size?: number | string;
  color?: string;
  className?: string;
}

const PixelHeart: React.FC<PixelHeartProps> = ({ size = 24, color = "currentColor", className = "" }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      xmlns="http://www.w3.org/2000/svg" 
      fill={color} 
      viewBox="0 0 24 24"
      className={className}
      style={{ imageRendering: 'pixelated' }}
    >
      <path d="M13 22h-2v-2h2v2Zm-2-2H9v-2h2v2Zm4 0h-2v-2h2v2Zm-6-2H7v-2h2v2Zm8 0h-2v-2h2v2ZM7 16H5v-2h2v2Zm12 0h-2v-2h2v2ZM5 14H3v-2h2v2Zm16 0h-2v-2h2v2ZM3 12H1V6h2v6Zm20 0h-2V6h2v6ZM13 8h-2V6h2v2ZM5 6H3V4h2v2Zm6 0H9V4h2v2Zm4 0h-2V4h2v2Zm6 0h-2V4h2v2ZM9 4H5V2h4v2Zm10 0h-4V2h4v2Z"/>
    </svg>
  );
};

export default PixelHeart;
