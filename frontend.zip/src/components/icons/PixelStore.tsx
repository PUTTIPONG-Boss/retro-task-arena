import React from 'react';

const PixelStore = ({ size = 24, className = "" }) => (
  <svg 
    width={size} 
    height={size} 
    className={className} 
    xmlns="http://www.w3.org/2000/svg" 
    fill="currentColor" 
    viewBox="0 0 24 24"
  >
    <path d="M10 21h4v-4h2v4h3v2H5v-2h3v-4h2v4Zm-4-8H5v8H3v-8H2v-2h4v2Zm16 0h-1v8h-2v-8h-1v-2h4v2Zm-8 4h-4v-2h4v2Zm0-4h-4v-2h4v2ZM2 11H0V7h2v4Zm8 0H6V9h4v2Zm8 0h-4V9h4v2Zm6 0h-2V7h2v4ZM4 7H2V5h2v2Zm18 0h-2V5h2v2Zm-2-2H4V3h16v2Z"/>
  </svg>
);

export default PixelStore;
