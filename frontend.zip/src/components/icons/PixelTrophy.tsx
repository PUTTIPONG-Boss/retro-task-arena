import React from 'react';

interface PixelTrophyProps {
  size?: number | string;
  color?: string;
  className?: string;
}

const PixelTrophy: React.FC<PixelTrophyProps> = ({ size = 24, color = "currentColor", className = "" }) => {
  return (
    <svg 
      width={size} 
      height={size} 
      xmlns="http://www.w3.org/2000/svg" 
      fill={color} 
      viewBox="0 0 24 24"
      className={className}
      style={{ imageRendering: 'pixelated' }}
    >
      <path d="M16 17h-3v2h2v2H9v-2h2v-2H8v-2h8v2Zm2-12h4v6h-2V7h-2v4h2v2h-2v2h-2V5H8v10H6v-2H4v-2h2V7H4v4H2V5h4V3h12v2Z"/>
    </svg>
  );
};

export default PixelTrophy;
