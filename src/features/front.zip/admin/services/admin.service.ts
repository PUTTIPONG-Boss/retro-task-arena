import { apiClient } from "@/lib/api";
import { UserProfile } from "@/features/users/types";

// Note: Backend /v1/user returns []*domain.User
// We might need to map it to UserProfile or a specific admin type

// เพิ่ม function ใหม่แทนการ filter ที่ frontend
export async function getUsersByRole(role: string): Promise<UserProfile[]> {
  const response = await apiClient.get(`/user/list?role=${role}`);
  const data = Array.isArray(response.data) ? response.data : (response.data.data || []);
  return data.map((u: any) => ({
    id: u.userId || u.id,
    username: u.username,
    email: u.email,
    role: u.role,
    points: u.points || 0,
    questsCompleted: u.questsCompleted || 0,
    rating: u.rating || 5.0,
    skills: u.skills ? u.skills.split(",") : [],
    github: u.github,
    linkin: u.linkin,
    firstNameTh: u.firstNameTh,
    lastNameTh: u.lastNameTh,
    firstNameEn: u.firstNameEn,
    lastNameEn: u.lastNameEn,
  }));
}

export async function getAllTasks(page = 1, limit = 20) {
  const response = await apiClient.get(`/tasks?page=${page}&limit=${limit}`);
  return Array.isArray(response.data) ? response.data : (response.data.data || []);
}

export async function getAllProducts(page = 1, limit = 20) {
  const response = await apiClient.get(`/product?page=${page}&limit=${limit}`);
  return Array.isArray(response.data) ? response.data : (response.data.data || []);
}
